package br.com.zup.pix.excecoes

class ContaNaoExistenteException(mensagem: String) : Exception(mensagem) {
}