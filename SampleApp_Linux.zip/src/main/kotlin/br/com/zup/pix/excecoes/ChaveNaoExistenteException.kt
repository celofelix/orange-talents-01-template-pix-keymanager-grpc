package br.com.zup.pix.excecoes

class ChaveNaoExistenteException(mensagem: String) : Exception(mensagem) {
}