package br.com.zup.pix.bcb

class DeletePixKeyRequest(
    val key: String,
    val participant: String
)