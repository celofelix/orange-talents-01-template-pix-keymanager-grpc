package br.com.zup.pix.itau

enum class TipoConta {

    CONTA_CORRENTE,
    CONTA_POUPANCA
}