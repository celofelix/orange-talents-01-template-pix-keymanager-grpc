package br.com.zup.pix.excecoes

class ChaveExistenteException(mensagem: String) : Exception(mensagem) {

}
